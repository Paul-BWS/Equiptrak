export default function PersonnelList() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Personnel</h1>
      <p>Personnel list will be implemented here.</p>
    </div>
  );
} 