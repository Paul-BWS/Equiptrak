import { Layout } from "@/components/Layout";

export default function CustomerServicePage() {
  return (
    <Layout>
      <div>Customer Service Page</div>
    </Layout>
  );
}