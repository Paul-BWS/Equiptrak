export default function SuppliersList() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Suppliers</h1>
      <p>Suppliers list will be implemented here.</p>
    </div>
  );
} 