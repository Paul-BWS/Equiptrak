import { Layout } from "@/components/Layout";

export default function CustomerEquipmentTypesPage() {
  return (
    <Layout>
      <div>Customer Equipment Types Page</div>
    </Layout>
  );
}