import { Layout } from "@/components/Layout";

export default function CustomerPage() {
  return (
    <Layout>
      <div>Customer Page</div>
    </Layout>
  );
}