import { Layout } from "@/components/Layout";

export default function ServicePage() {
  return (
    <Layout>
      <div>Service Page</div>
    </Layout>
  );
}